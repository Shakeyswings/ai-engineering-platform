# AI Engineering Platform - UI/UX Design Constraints

**This document is the visual law.** Every component, screen, and interaction must comply with these rules.

---

## 🎨 Color Palette (MANDATORY)

### Background & Surfaces
```
--bg-primary:        #0F1419  (Deep navy - main bg)
--bg-secondary:      #1A1F2E  (Card backgrounds)
--bg-tertiary:       #242D3D  (Elevated surfaces, hover states)
--bg-hover:          #2D3748  (Subtle hover lift)
```

### Accent Colors (Use Strategically)
```
--accent-cyan:       #00D4FF  (Primary CTA, highlights, active states)
--accent-teal:       #00D9A3  (Success, completed, secondary CTA)
--accent-purple:     #7C5AFA  (Gamification, rewards, badges)
```

### Semantic Colors
```
--color-success:     #2ED573  (Approved, deployed, complete)
--color-warning:     #FFA502  (Needs review, caution, pending)
--color-danger:      #FF4757  (Error, failed, blocked)
--color-info:        #00D4FF  (Information, hint, detail)
```

### Text
```
--text-primary:      #FFFFFF      (Main headings, body text)
--text-secondary:    #A8B0C0      (Labels, descriptions, muted)
--text-tertiary:     #6B7280      (Metadata, timestamps, helpers)
--text-inverted:     #0F1419      (Text on light backgrounds)
```

### Borders & Dividers
```
--border-default:    #2D3748  (Cards, inputs, dividers)
--border-accent:     #00D4FF  (Focused, active, highlight)
--border-danger:     #FF4757  (Error states)
```

**Rule:** NEVER introduce new colors. If a new semantic is needed, ask to extend this palette.

---

## 🔤 Typography (MANDATORY)

### Font Stack
```css
font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
```

### Type Scale (px / weight / line-height)

| Use Case | Size | Weight | Line-Height | Margins |
|----------|------|--------|-------------|---------|
| **H1 (Hero)** | 48px | 700 | 1.1 | 0 bottom, 16px top |
| **H2 (Page Title)** | 32px | 700 | 1.2 | 0 bottom, 12px top |
| **H3 (Section)** | 24px | 600 | 1.3 | 0 bottom, 8px top |
| **H4 (Subsection)** | 18px | 600 | 1.4 | 0 bottom, 4px top |
| **Body (Default)** | 14px | 400 | 1.6 | 0 |
| **Small (Label)** | 12px | 500 | 1.5 | 0 |
| **Tiny (Meta)** | 11px | 400 | 1.4 | 0 |
| **Code/Mono** | 12px | 400 | 1.5 | Use `<code>` or `<pre>` |

### Rules
- ✅ MUST maintain 1.6 line-height for readability (body text)
- ✅ MUST use Inter for everything (no custom fonts except Fira Code for code blocks)
- ✅ MUST keep contrast ratio ≥ 4.5:1 for all readable text
- ✅ NEVER mix weights within a single line (either 400 or 700, not both)
- ✅ NEVER use font sizes outside the scale above
- ❌ NO ALL-CAPS except labels and system messages

---

## 📦 Spacing & Layout Grid (4px Base)

Every measurement MUST be a multiple of 4px.

```
4px   = Micro (internal component space)
8px   = Tight (related elements)
12px  = Small (element groups)
16px  = Base (section spacing, padding)
24px  = Medium (card padding, major content spacing)
32px  = Large (section separation)
48px  = XL (page-level spacing, hero sections)
64px  = XXL (dramatic spacing, between major sections)
```

### Application Rules

| Element | Padding | Margin | Rule |
|---------|---------|--------|------|
| **Button** | 12px H × 16px V | 8px all | No exceptions |
| **Card** | 16px - 24px | 16px bottom | Content-dependent |
| **Input** | 12px H × 12px V | 12px bottom | Vertical stack |
| **List Item** | 12px H × 8px V | 0 | Nested inside card |
| **Section** | 0 | 32px bottom | Major sections |
| **Page** | 48px | 0 | Outer container |

**Rule:** Use CSS variables or Tailwind spacing utilities only. Never use random pixels.

---

## 🎯 Component Specifications

### Card Component
```
MUST:
├─ Background: bg-secondary (#1A1F2E)
├─ Border: 1px solid border-default (#2D3748)
├─ Border-radius: 8px
├─ Padding: 16px (compact) or 24px (content-rich)
├─ Box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3)
├─ Hover state: border shifts to --accent-cyan (no fill change)
└─ Transition: all 150ms ease-out

NEVER:
├─ X Semi-transparent overlays
├─ X Thick shadows
├─ X Rounded corners >8px
└─ X Full-width backgrounds
```

### Button Specifications

#### Primary (CTA - Prominent Actions)
```
Background:    --accent-cyan (#00D4FF)
Text:          #0F1419 (inverted)
Padding:       12px H × 16px V
Border-radius: 8px
Font-size:     14px / 600
Hover:         brightness-110 (slightly lighter)
Active:        brightness-90 (pressed state)
Disabled:      opacity-50, cursor-not-allowed
Transition:    all 150ms ease-out
Width:         Full or 100% in forms
Icon spacing:  8px left of text
```

#### Secondary (Regular Actions)
```
Background:    border-default (#2D3748)
Text:          --text-primary (#FFFFFF)
Border:        1px solid border-default
Padding:       12px H × 16px V
Hover:         background lighten 10%
Focus:         outline 2px offset 2px --accent-cyan
```

#### Danger (Destructive)
```
Background:    --color-danger (#FF4757)
Text:          #FFFFFF
Padding:       12px H × 16px V
Hover:         brightness-110
Disabled:      opacity-50
Requires:      Explicit user confirmation
```

#### Icon Button (No text)
```
Size:          40px × 40px (minimum)
Background:    transparent on normal, bg-tertiary on hover
Border:        none, or 1px transparent
Icon size:     20px
Border-radius: 6px
```

**Rule:** All buttons must have visible focus indicators (outline or border).

### Form Input Specifications
```
Background:      --bg-tertiary (#242D3D)
Border:          1px solid --border-default (#2D3748)
Border-radius:   6px
Padding:         12px H × 12px V
Font-size:       14px / 400
Text color:      --text-primary (#FFFFFF)
Placeholder:     --text-tertiary (#6B7280)
Focus:           2px solid --border-accent (#00D4FF)
Error:           2px solid --color-danger (#FF4757)
Disabled:        opacity-50, cursor-not-allowed
Transition:      border-color 150ms ease-out
```

### Status Badge Specifications
```
Format:        Inline label with color dot + text
Size:          12px font, 6px dot
Padding:       4px H × 6px V
Border-radius: 4px (pill-shaped)

Success:       🟢 bg-success, text-white
Warning:       🟠 bg-warning, text-black
Error:         🔴 bg-danger, text-white
Info:          🔵 bg-info, text-black
In Progress:   🔵 bg-cyan, text-black
```

### Divider / Separator
```
Height:        1px
Color:         --border-default (#2D3748)
Margin:        16px V, 0 H
Never:         Use as visual "heavy" element
```

### Modal / Dialog
```
Overlay:       rgba(15, 20, 25, 0.8) (semi-transparent dark)
Container:     bg-secondary, border 1px border-default
Border-radius: 12px
Padding:       24px
Max-width:     500px (default), 600px (form)
Shadow:        0 20px 25px rgba(0, 0, 0, 0.5)
Backdrop-blur: (optional) 4px
```

### Progress Indicator

#### Linear (Horizontal)
```
Height:         8px
Background:     --border-default (#2D3748)
Fill:           --accent-cyan (#00D4FF)
Border-radius:  4px
Animation:      smooth transition on value change
```

#### Circular (Donut/Ring)
```
Radius:         40px (outer)
Width:          8px (stroke)
Background:     --border-default (#2D3748)
Fill:           --accent-cyan (#00D4FF)
Rotation:       counter-clockwise
Label:          Center text (percentage or status)
```

---

## 🎮 Gamification Component Specs

### Achievement Badge
```
Shape:         Circle or rounded square
Size:          64px × 64px (large), 48px × 48px (small)
Background:    --accent-purple (#7C5AFA)
Icon:          24px-32px, centered, white
Border:        2px solid --accent-teal
Shadow:        0 8px 24px rgba(124, 90, 250, 0.3)
Animation:     Pulse on unlock (scale 1 → 1.1 → 1 over 600ms)
Label:         12px text below, center-aligned
```

### Streak Counter
```
Format:        🔥 {count} day streak
Position:      Top-right of dashboard (sticky)
Background:    --accent-purple (#7C5AFA) with gradient
Padding:       8px H × 12px V
Border-radius: 20px (pill)
Font:          14px / 600
Animation:     Subtle pulse when streak updates
```

### Reward Toast Notification
```
Position:      Bottom-right (above other toasts)
Background:    --accent-teal (#00D9A3)
Text:          --text-inverted (#0F1419)
Icon:          Star or trophy, 24px
Message:       14px / 500, max 2 lines
Duration:      Show 4s, fade-out over 300ms
Animation:     Slide-in from bottom-right
Sound:         (optional) Subtle chime
```

### Progress Ring (Gamified Mission Card)
```
Inner circle:  Shows current mission count
Ring fill:     --accent-cyan (#00D4FF)
Ring bg:       --border-default (#2D3748)
Outer ring:    Next milestone hint
Rotation:      Counter-clockwise
Size:          80px diameter (card footer)
```

---

## 🎯 Layout Patterns

### Dashboard Grid
```
Breakpoints:   Desktop (≥1440px), Tablet (≥768px)
Column count:  4-column (desktop), 2-column (tablet)
Gap:           24px (desktop), 16px (tablet)
Outer margin:  48px (desktop), 24px (tablet)
```

### Mission Card Layout
```
Header:        Mission title + status badge
Body:          Objective, context (truncated), metadata
Footer:        Progress ring + Action button (View/Edit/Approve)
Height:        300px (fixed)
Hover:         Border color → accent-cyan, slight shadow increase
```

### Two-Column Form (Mission Creation)
```
Desktop:       Left (50%) for form fields, Right (50%) for preview/hints
Tablet:        Full-width stack
Gap:           32px
Alignment:     Top-aligned
```

### Data Table
```
Header:        Sticky, bg-tertiary, 14px / 600
Rows:          Alternating bg-secondary / bg-hover (every other row)
Height:        32px per row
Border:        1px bottom, border-default
Hover row:     bg-hover, cursor-pointer
Padding:       12px H × 8px V per cell
Responsive:    Horizontally scrollable on mobile
```

---

## 🎨 Interaction & Animation Rules

### Transition Speeds
```
Micro:         100ms (hover, focus states)
Fast:          150ms (button clicks, color changes)
Normal:        300ms (modal open, card expand)
Slow:          600ms (gamification rewards, major layout shifts)
Never:         Anything >1000ms (feels slow)
```

### Timing Function
```
Default:       ease-out (most natural)
Snappy:        cubic-bezier(0.4, 0, 0.2, 1)
Easing:        cubic-bezier(0.25, 0.46, 0.45, 0.94)
Bounce:        cubic-bezier(0.68, -0.55, 0.265, 1.55)
```

### Hover Effects
```
Button:        brightness-110 (lighter)
Card:          border-color → accent-cyan, shadow increase
Input:         border-color → accent-cyan
Link:          underline + color change
Icon:          scale-110 over 150ms
```

### Focus States (Keyboard Navigation)
```
All interactive elements MUST have:
├─ outline: 2px solid --accent-cyan
├─ outline-offset: 2px
├─ Visible at all times (never hidden by -webkit-focus-ring-color)
└─ Contrast ratio ≥ 4.5:1
```

### Loading States
```
Spinner:       Rotating circle (--accent-cyan)
Skeleton:      Pulse animation (bg-tertiary, opacity 0.6 → 0.9)
Button:        Show spinner inside, disable interaction
Duration:      Always show for ≥1s (no flash)
```

---

## 📱 Responsive Design Rules

### Breakpoints
```
Mobile:        <768px  (secondary support, mobile only on core flows)
Tablet:        768px-1440px (primary tablet experience)
Desktop:       ≥1440px (primary target)
```

### Mobile (Tablet Minimum)
```
Hide:          Sidebar (hamburger menu)
Stack:         All grids vertically
Padding:       16px (reduced from 48px)
Buttons:       Full-width
Modals:        90vh height, fit to keyboard
Font:          No change (Inter still 14px body)
Touch targets: Minimum 44px × 44px
```

### Sidebar Behavior
- Desktop: Always visible, 240px width
- Tablet: Collapse to icon-only, expand on hover (240px)
- Mobile: Hidden by default, hamburger menu

---

## ✅ QA Checklist for Every Component

- ✅ Follows color palette exactly (no new colors)
- ✅ Uses only type scale defined above
- ✅ Spacing is multiple of 4px
- ✅ All interactive elements have focus rings
- ✅ Hover/active states defined
- ✅ Disabled state handled
- ✅ Accessible color contrast ≥4.5:1
- ✅ Works on desktop, tablet (mobile tertiary)
- ✅ No console errors
- ✅ Animations <600ms, easing matches standard
- ✅ Responsive without media query hacks
- ✅ Icon sizes match spec (20px, 24px, 32px)
- ✅ Component passes Lighthouse A11y ≥90

---

## 🚫 Design Anti-Patterns (NEVER DO)

- ❌ New colors without palette update
- ❌ Font sizes outside the type scale
- ❌ Padding/margins not multiples of 4px
- ❌ Shadows with no blur (sharp shadows)
- ❌ Gradients (they cloud the brand)
- ❌ Animations >600ms or without easing
- ❌ Focus rings hidden or removed
- ❌ Text contrast <4.5:1
- ❌ Mixing typefaces (Inter only)
- ❌ Cute or playful emojis (professional tone)
- ❌ Rounded corners >12px
- ❌ Hover effects that don't have matching focus effects
- ❌ 100% full-width buttons on desktop (max 500px)
- ❌ Modal overlays with opacity <0.7
- ❌ Clickable elements without pointer cursor
- ❌ Color as only indicator (must pair with icon/text)

---

## 🎯 Design System File Locations

When GPT asks for "the design system," point it to:
1. **CONTEXT.md** – Architecture & philosophy
2. **UI_CONSTRAINTS.md** – This file, visual rules
3. **Component examples** – Existing components in `/components`
4. **Figma** (if you have one) – Source of truth for design

---

**Last Updated:** 2026-07-03
**Strictness Level:** MANDATORY (no exceptions without written approval)
**Owned by:** Design System Lead
