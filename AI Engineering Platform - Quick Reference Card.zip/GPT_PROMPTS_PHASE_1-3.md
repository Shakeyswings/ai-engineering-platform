# AI Engineering Platform - GPT Prompts for UI/UX Elevation

**Use these prompts verbatim with GPT.** Each prompt is tested and optimized for output quality.

---

## 📋 How to Use This File

1. **Copy the entire prompt below** (everything in the code block)
2. **Paste into GPT (Claude, ChatGPT, etc.)**
3. **Attach these files to your message:**
   - `CONTEXT.md`
   - `UI_CONSTRAINTS.md`
   - Current component code (paste relevant files)
4. **Hit Send**
5. **GPT will generate:** Components, CSS, full code, no explanation (just code)

---

---

# 🎯 PHASE 1: Dashboard & Card Components Redesign

**Target:** Make the dashboard visually stunning, add gamification elements, ensure perfect visual hierarchy

**Execution Time:** 2-3 hours (GPT), 30 min review (you)

**Paste this entire prompt to GPT:**

```
You are a Senior UI/UX Engineer specializing in dashboard design and gamification.

Your mission:
Redesign the AI Engineering Platform dashboard and core card components to be visually stunning, 
easy to navigate, and semi-gamified. The dashboard is the command center—every element must feel 
intentional and data-rich.

Constraints (MANDATORY):
- MUST follow CONTEXT.md and UI_CONSTRAINTS.md exactly (no deviations)
- MUST use only the color palette defined (no new colors)
- MUST use Inter font exclusively
- MUST use 4px spacing grid throughout
- MUST ensure all text contrast ≥4.5:1
- MUST include focus rings on all interactive elements
- MUST animate in <600ms
- NO gradients, NO cute emojis, NO excessive shadows

Visual Direction:
- Theme: Dark mode enterprise control room (think Stripe + Linear aesthetics)
- Tone: Professional, calm, trustworthy, command-authority
- Data density: Medium (info-rich but not cluttered)
- Gamification: Subtle, motivating, <15% of screen real estate
- Motion: Smooth, responsive, snappy (150-300ms)

Deliverables (BUILD THESE):

1. **Dashboard Layout Component** (`Dashboard.tsx`)
   - Hero section with current stats (missions deployed, approval rate, streak)
   - 4-column grid of key metrics (KPI cards)
   - Active Missions section (shows 3-4 recent missions with status)
   - Pending Approvals alert (if any exist, full-width red bar)
   - Recent Activity timeline feed (last 5 activities)
   - Sidebar navigation (240px fixed on desktop, collapsible tablet)
   - Header bar with logo, user profile, notifications
   - Footer with system status, help link, dark mode toggle

   Interactions:
   - KPI cards: Hover shows drill-down link
   - Mission card: Click → navigate to mission detail page
   - Approval alert: Click → jump to approval page
   - Sidebar: Smooth collapse/expand transition
   - All animations in 150-300ms range

2. **Mission Card Component** (`MissionCard.tsx`)
   - Header: Mission title (18px / 600) + Status badge (right-aligned)
   - Body: Objective (2 lines truncated) + Complexity indicator
   - Footer: Progress ring (gamified) + CTA button
   - Dimensions: 300px height (fixed), full width of grid cell
   - Hover: Border → --accent-cyan, shadow increase, slight lift (2px up)
   - Status badge colors: In Progress (cyan), Review (warning), Approved (teal), Deployed (success)
   - Progress ring: Shows missions completed toward next achievement
   - CTA button: Primary (View Details / Edit / Approve based on status)

3. **KPI Card Component** (`KPICard.tsx`)
   - Title (12px / 500, uppercase, --text-tertiary)
   - Large metric value (32px / 700, --text-primary)
   - Trend indicator (arrow up/down, color-coded)
   - Sparkline chart (tiny line chart, 100x40px, --accent-cyan)
   - Background: bg-secondary with 1px border
   - Hover: Border → accent-cyan, cursor-pointer
   - Clickable for drill-down (optional)

4. **Achievement Badge Component** (`AchievementBadge.tsx`)
   - Shape: Circle, 64px × 64px
   - Background: --accent-purple (#7C5AFA)
   - Icon: 32px, centered, white (trophy, star, lightning, etc.)
   - Border: 2px solid --accent-teal
   - Shadow: 0 8px 24px rgba(124, 90, 250, 0.3)
   - Label: 12px text below, 2-3 words max
   - Animation: Pulse on first render (scale 1 → 1.1 → 1 over 600ms)
   - Tooltip: Show on hover with achievement description

5. **Streak Counter Component** (`StreakCounter.tsx`)
   - Position: Sticky, top-right of dashboard
   - Format: 🔥 {number} day streak
   - Background: --accent-purple with subtle gradient overlay
   - Padding: 8px H × 12px V
   - Font: 14px / 600
   - Border-radius: 20px (pill shape)
   - Animation: Pulse effect when streak updates (subtle, 300ms)
   - Click: Expand to show streak breakdown by week

6. **Status Indicator Component** (`StatusIndicator.tsx`)
   - Inline label with dot indicator
   - Sizes: Small (12px), Medium (14px), Large (16px)
   - Format: • {status text}
   - Colors: Success (green), Warning (orange), Error (red), Info (cyan), In Progress (cyan pulse)
   - Pulsing animation: For "In Progress" status (opacity 0.5 → 1 over 2s loop)

7. **Sidebar Navigation** (`Sidebar.tsx`)
   - Width: 240px (desktop), 60px (collapsed/tablet)
   - Background: bg-secondary
   - Logo area: 24px icon + text (logo name)
   - Menu items: 
     * Dashboard
     * Missions
     * Tasks
     * Approvals
     * Evaluations
     * System
     * Settings
   - Current page: Highlight with --accent-cyan left border (4px)
   - Hover: bg-tertiary, cursor-pointer
   - Collapse button: Top-left, smooth transition
   - Icons: 20px, from Lucide React library

8. **Gamification Reward Toast** (`RewardToast.tsx`)
   - Position: Bottom-right, above other toasts
   - Background: --accent-teal (#00D9A3)
   - Text color: --text-inverted (#0F1419)
   - Message: "You earned: {badge_name}" (14px / 500)
   - Icon: Trophy or star (24px)
   - Duration: Show 4s, fade-out 300ms
   - Animation: Slide-in from bottom-right over 300ms
   - Sound: (Optional) Subtle chime (check if available)

Technical Requirements:
- Use Tailwind CSS with custom CSS variables (provided in UI_CONSTRAINTS.md)
- Component prop interfaces: TypeScript strict mode
- No external animation libraries (use CSS transitions/keyframes)
- Export as default from each file
- Include Lucide React icons (lucide-react v0.383.0)
- Responsive: Desktop (≥1440px primary), Tablet (768px) secondary
- Example: MissionCard should show full layout desktop, half-width tablet, stack mobile

Code Quality:
- Clean, readable code (max 150 lines per component)
- Comments for complex logic only
- Component documentation via JSDoc
- No console errors or warnings

Output Format:
PROVIDE ONLY CODE. No explanation, no markdown, no preamble.
Start with component file, end with import statements needed.

Build me these 8 components now. GO.
```

---

---

# 🎯 PHASE 2: Mission Creation Form & Gamification

**Target:** Beautiful, intuitive form with progress indication and reward system

**Execution Time:** 2-3 hours (GPT), 30 min review (you)

**Paste this entire prompt to GPT:**

```
You are a Senior UI/UX Engineer specializing in form design and gamified experiences.

Your mission:
Redesign the Mission Creation form to be delightful, with step-by-step guidance, progress tracking,
and gamification rewards for form completion. Forms are typically boring—make this one feel rewarding.

Context Files: CONTEXT.md and UI_CONSTRAINTS.md (attached)

Constraints (MANDATORY):
- MUST follow all rules in UI_CONSTRAINTS.md exactly
- MUST use the color palette (no new colors)
- MUST use only Inter font
- MUST maintain 4px spacing grid
- MUST keep form completion time <3 minutes (with tooltips)
- MUST have visible validation (inline, not on submit)
- MUST show loading state during form submission

Visual Direction:
- Layout: Two-column (desktop) — left side form, right side preview/hints
- Interaction: Progressive disclosure (show fields as relevant)
- Feedback: Real-time validation, helpful error messages
- Motivation: Progress bar at top, micro-rewards for field completion
- Tone: Encouraging, clear, jargon-free

Deliverables (BUILD THESE):

1. **Mission Form Container** (`MissionForm.tsx`)
   - Header: "Create a Mission" (H2, 32px)
   - Subheader: "Define the work clearly..." (14px, --text-secondary)
   - Two-column layout (desktop): Form left (60%), Hints/Preview right (40%), 32px gap
   - Stack vertically on tablet/mobile
   - Form fields below (see next components)

2. **Form Progress Indicator** (`FormProgress.tsx`)
   - Position: Sticky, top of form
   - Style: Horizontal linear progress bar (8px height)
   - Color: --accent-cyan
   - Shows: "Step X of Y" (12px / 500, right-aligned)
   - Logic: Calculate based on filled vs total fields
   - Animation: Smooth width transition (200ms) as user fills form
   - Milestone markers: Show badges at 25%, 50%, 75%, 100%

3. **Form Field Component** (`FormField.tsx`)
   - Wrapper for all form fields with consistent styling
   - Props: label, placeholder, value, onChange, error, hint, required
   - Layout: Label above, input below, hint/error below input
   - Label: 12px / 500, --text-secondary
   - Hint: 12px / 400, --text-tertiary (always visible)
   - Error: 12px / 500, --color-danger (only on error)
   - Styling per UI_CONSTRAINTS.md (Form Input spec)
   - Validation: Real-time (on blur), show check mark (✓) when valid
   - Accessibility: htmlFor linking, aria-invalid, aria-describedby

4. **Mission Title Input** (within FormField)
   - Label: "Mission Title"
   - Placeholder: "e.g., Redesign Dashboard"
   - Max length: 80 characters (show counter: "45/80")
   - Validation: 
     * Min 5 chars
     * No special characters except dash/underscore
   - Hint: "Give your mission a clear, actionable name"
   - Focus: Expand slightly, border → --accent-cyan

5. **Objective Textarea** (within FormField)
   - Label: "Objective"
   - Placeholder: "What do you want to achieve?"
   - Height: 120px (auto-expand up to 200px)
   - Max length: 500 characters
   - Validation: Min 20 chars
   - Hint: "Be specific. What's the measurable outcome?"
   - Textarea styling per UI_CONSTRAINTS.md

6. **Context Textarea** (within FormField)
   - Label: "Context"
   - Placeholder: "Why is this mission important? What's the background?"
   - Height: 100px
   - Max length: 300 characters
   - Validation: Min 10 chars (optional)
   - Hint: "Help your AI assistant understand the bigger picture"

7. **Constraints Textarea** (within FormField)
   - Label: "Constraints"
   - Placeholder: "What are the limits? Budget? Timeline? Resources?"
   - Height: 100px
   - Max length: 300 characters
   - Validation: Min 5 chars
   - Hint: "Be realistic. Constraints shape the plan."

8. **Success Criteria Textarea** (within FormField)
   - Label: "Success Criteria"
   - Placeholder: "How will you know the mission succeeded?"
   - Height: 100px
   - Max length: 250 characters
   - Validation: Min 10 chars
   - Hint: "Define measurable, clear success."

9. **Complexity Selector** (`ComplexitySelector.tsx`)
   - Label: "Complexity Level"
   - Options: Low, Medium, High (radio buttons or buttons)
   - Visual: Solid color indicators (Low: teal, Medium: cyan, High: purple)
   - Selected state: Full background + checkmark
   - Unselected: Just border outline
   - Hover: bg-tertiary
   - Help text: "Complexity affects timeline and approval gates"

10. **Right Panel - Form Hints** (`FormHints.tsx`)
    - Fixed position on desktop, stacked on mobile
    - Content sections (collapsible):
      * "💡 Tips" — Best practices for mission definition
      * "🎯 Example" — Sample filled-out mission
      * "📊 Preview" — Live preview of generated mission
    - Background: bg-tertiary, border 1px border-default
    - Padding: 16px
    - Border-radius: 8px
    - Font: 13px / 400

11. **Form Submit Section** (`FormSubmitSection.tsx`)
    - Full-width button: "Generate Mission Plan"
    - Style: Primary (--accent-cyan background)
    - Size: 48px height
    - State: Disabled while any required field empty
    - Loading state: Show spinner inside button, disable
    - Success state: Show checkmark, slide to next page
    - Validation summary: Show above button if errors exist
      * List all validation errors (red text, checkmark bullets)

12. **Field Completion Reward** (`FieldRewardBadge.tsx`)
    - Appears on right when a field is completed/valid
    - Shows: Small animation (checkmark + "✓") for 1s then fades
    - Position: Float in from right
    - Color: --accent-teal
    - Animation: Slide-in (300ms), fade-out (200ms) after 1s delay

Technical Requirements:
- Use React Hook Form for form state management
- Zod or Yup for validation schema
- Tailwind CSS with custom variables
- Icons from lucide-react
- Responsive: Desktop (2-col), Tablet/Mobile (stack)
- LocalStorage: Persist form state (auto-save drafts)
- No external animation libraries

Interactions:
- Tab between fields (proper focus management)
- Enter submits (on last field)
- Real-time character counters
- Disabled submit button until all required fields filled
- Smooth field transitions (focus/blur)

Output Format:
PROVIDE ONLY CODE. No explanation, no markdown preamble.
Include all 12 components in order, with imports at the end.

Build me this entire form experience. GO.
```

---

---

# 🎯 PHASE 3: Approval Gates & Evaluation Detail Pages

**Target:** Clear, authoritative approval workflow with detailed evaluation scoring

**Execution Time:** 2-3 hours (GPT), 30 min review (you)

**Paste this entire prompt to GPT:**

```
You are a Senior UI/UX Engineer specializing in decision workflows and data visualization.

Your mission:
Build the Approval Gate and Mission Evaluation Detail Page. These are critical decision points.
The design must make the decision easy, the data clear, and the action obvious.

Context Files: CONTEXT.md and UI_CONSTRAINTS.md (attached)

Constraints (MANDATORY):
- Follow UI_CONSTRAINTS.md exactly
- Use defined color palette only
- Inter font exclusively
- 4px spacing grid
- All text ≥4.5:1 contrast
- Animations <600ms
- Focus rings on all interactive elements

Visual Direction:
- Tone: Authoritative, data-driven, clarity-first
- Complexity: Show what matters, hide what doesn't (progressive disclosure)
- Decision: Make the approve/reject/request-changes action crystal clear
- Data viz: Simple charts, high information density
- Hierarchy: Decision point first, details second

Deliverables (BUILD THESE):

1. **Approval Gate Modal** (`ApprovalGateModal.tsx`)
   - Title: "Approve Mission" or "Approve Deployment" (H3, 24px)
   - Content layout: Top (summary), Middle (risk assessment), Bottom (decision buttons)
   - Overlay: rgba(15, 20, 25, 0.8), blur (4px optional)
   - Container: bg-secondary, border 1px border-default, 600px max-width
   - Padding: 24px
   - Shadow: 0 20px 25px rgba(0, 0, 0, 0.5)
   - Close button: Top-right (X icon, 24px)

2. **Approval Summary Card** (`ApprovalSummaryCard.tsx`)
   - Section in modal: What's being approved
   - Show: Mission title (18px / 600) + brief objective
   - Show: Who submitted it + timestamp
   - Show: Current status badge
   - Background: bg-tertiary
   - Border: 1px border-default
   - Padding: 16px
   - Border-radius: 8px

3. **Risk Assessment Panel** (`RiskAssessmentPanel.tsx`)
   - Section in modal: Automatically detected risks
   - Header: "Risk Assessment" (14px / 600)
   - Display: List of risks (if none, show "✓ No risks detected")
   - Risk item: Icon (warning, error, info) + risk text + severity badge
   - Severity levels: High (danger color), Medium (warning), Low (info)
   - Each risk: Clickable to show details/mitigation
   - Background: bg-tertiary (subtle)
   - Padding: 12px per item

4. **Recommendation Section** (`RecommendationSection.tsx`)
   - AI-generated recommendation (e.g., "Recommended: APPROVE")
   - Icon: Checkmark (success), alert (caution), x (reject)
   - Confidence: "95% confidence" (small, --text-secondary)
   - Reason: One-line summary (14px / 400)
   - Styling: bg-tertiary with left 4px border (color-coded)

5. **Decision Buttons Panel** (`ApprovalDecisionPanel.tsx`)
   - Bottom of modal: Three primary action buttons
   - Button 1: "Approve" (primary --accent-cyan)
   - Button 2: "Request Changes" (secondary)
   - Button 3: "Reject" (danger)
   - Layout: Flex, space-between, full-width buttons
   - Hover: Standard button hover (brightness-110)
   - Active/Loading: Show spinner inside button
   - On click: Show confirmation dialog if destructive (reject)

6. **Mission Evaluation Detail Page** (`EvaluationDetailPage.tsx`)
   - Layout: Header + Hero (scores) + Category breakdown + Revision history
   - Header: Back link + "Evaluation" label
   - Hero section: Large evaluation score (0-100) in circle
     * Circle: 120px diameter
     * Color: Green (95+), Teal (90-94), Cyan (70-89), Red (<70)
     * Score text: 32px / 700
     * Subtext: "Excellent" / "Good" / "Needs Work" / "Rejected"
   - Overall status: "Approved for deployment" or "Needs revision"

7. **Scoring Category Cards** (`ScoringCategoryCard.tsx`)
   - Show 6 categories side-by-side (grid, desktop) or stack (mobile)
   - Each card:
     * Category name: Accuracy, Completeness, Usability, Risk, Source Quality, Format Compliance
     * Score: Large number (24px / 700) + small circle indicator
     * Bar chart: Horizontal bar showing score/100
     * Color: Matches score level
     * Hover: Show details (category definition + feedback)
   - Card style: bg-secondary, border 1px, 8px radius, padding 12px

8. **Detailed Feedback Section** (`DetailedFeedbackSection.tsx`)
   - Below score cards
   - Title: "Feedback" (H3, 24px)
   - Sections per category (expandable/collapsible):
     * Category name (14px / 600, --accent-cyan)
     * Feedback text (14px / 400, --text-secondary)
     * Suggestions (if any, bulleted list)
     * Click to expand/collapse with smooth animation
   - Card styling: bg-tertiary, 1px border

9. **Evaluation History Timeline** (`EvaluationHistoryTimeline.tsx`)
   - Shows all past evaluations for this mission
   - Vertical timeline (left side indicator, right side content)
   - Each entry:
     * Timestamp (12px / 400, --text-tertiary)
     * Score (e.g., "87/100")
     * Status (e.g., "Approved" green badge)
     * Evaluator (if human-reviewed)
   - Color-coded: Green (passed), Yellow (warning), Red (failed)
   - Clickable to view that evaluation snapshot

10. **Patch/Revision Suggestion Card** (`PatchSuggestionCard.tsx`)
    - If score <95, show this prominently
    - Title: "Suggested Revisions"
    - List the top 3 areas needing work
    - Each item: Icon (priority) + text + "Fix this" link
    - CTA button: "Request revision" (secondary button)
    - Background: bg-warning (pale), 1px warning border, padding 16px

11. **Approval Audit Trail** (`ApprovalAuditTrail.tsx`)
    - Shows history of approvals/rejections for this mission
    - Timeline format:
      * Avatar/initials of approver
      * Action (Approved / Rejected / Requested Changes)
      * Timestamp (relative, e.g., "2 hours ago")
      * Comment (if provided)
    - Each entry clickable to see full details
    - Styling: Clean, minimal, 12px / 400 text

12. **Deploy Confirmation Modal** (`DeployConfirmationModal.tsx`)
    - After approve, confirm deployment
    - Title: "Ready to Deploy?"
    - Content: Mission summary + "This action cannot be undone"
    - Buttons: "Deploy Now" (primary), "Cancel" (secondary)
    - Loading state: Show spinner, disable buttons during deployment
    - Success: Show checkmark, redirect to mission detail page

Technical Requirements:
- TypeScript strict mode
- Use recharts for score visualization (bar charts, pie charts)
- Animations: CSS transitions, no libraries
- Icons: lucide-react
- State: React Context for approval workflow state
- Real-time: Show live status updates during approval
- Responsive: Desktop primary, tablet secondary, mobile tertiary

Interactions:
- Smooth modal open/close (300ms)
- Expandable sections with smooth animation
- Hover states on all cards
- Keyboard navigation (Tab through buttons)
- Focus rings visible always

Output Format:
PROVIDE ONLY CODE. No explanation, markdown preamble, or narration.
Include all 12 components with imports.

Build me this approval + evaluation system. GO.
```

---

---

## 🎨 Advanced: Gamification & Achievement System

**Target:** Full achievement, badge, and leaderboard system (optional Phase 4+)

**Paste this to GPT when ready:**

```
You are building an achievement & reward system that motivates without distracting.

Mission:
Create a gamification suite: achievements, badges, streaks, leaderboards, and XP tracking.
Keep it elegant, non-intrusive, and motivating.

Constraints: All UI_CONSTRAINTS.md rules apply. No skeuomorphism, no excessive animations.

Deliverables:

1. **Achievement Card** (`AchievementCard.tsx`)
   - Locked/Unlocked states
   - Progress bar for partial achievements
   - Hover animation (slight scale, border glow)

2. **Leaderboard Component** (`Leaderboard.tsx`)
   - User rankings by missions deployed
   - Sortable by different metrics
   - Current user highlighted
   - Responsive table or card grid

3. **XP Progress Bar** (`XPProgressBar.tsx`)
   - Shows current level + progress to next
   - Animated fill on XP gain
   - Level badge with icon

4. **Streak Display** (`StreakWidget.tsx`)
   - Shows current streak + best streak
   - Calendar heatmap (optional)
   - Celebratory animation on new record

5. **Achievement Unlock Animation** (`AchievementUnlock.tsx`)
   - Full-screen confetti or particle animation
   - Achievement card flies in
   - Audio chime (optional)
   - Auto-dismiss after 5s

Build these components. GO.
```

---

---

## 📋 Implementation Checklist

After GPT generates code:

- [ ] Run `npm run dev` locally
- [ ] Test each component in isolation
- [ ] Check focus rings on all interactive elements
- [ ] Verify color contrast (use WebAIM contrast checker)
- [ ] Test animations (should feel snappy, not laggy)
- [ ] Check responsive behavior (desktop, tablet, mobile)
- [ ] Test form validation (inline, clear errors)
- [ ] Verify approval flow end-to-end
- [ ] Check console for errors/warnings
- [ ] Run Lighthouse A11y scan (target ≥90)
- [ ] Commit to GitHub with message: "Phase [1-3]: UI/UX elevation - [component names]"
- [ ] Deploy preview to Vercel for stakeholder review

---

## 🔗 Next Steps (After Each Phase)

**Phase 1 Complete?**
→ Go to Phase 2 prompt (Mission Form)

**Phase 2 Complete?**
→ Go to Phase 3 prompt (Approval + Evaluation)

**Phase 3 Complete?**
→ Move to Phase 4: Real-time subscriptions, live activity feed, performance tuning

---

## 💡 Pro Tips for Working with GPT

1. **Paste CONTEXT.md + UI_CONSTRAINTS.md** in every message (or link them)
2. **Be specific** about what you want (not "make it look better," but "add streak counter")
3. **Provide examples** if you have them (show good/bad examples)
4. **Check the output** immediately (don't wait until later to find issues)
5. **Ask for refinements** ("Make buttons bigger," "Change the badge color to purple")
6. **Version control** every phase (GitHub branch per phase)

---

**Last Updated:** 2026-07-03
**Status:** Ready to Send to GPT
