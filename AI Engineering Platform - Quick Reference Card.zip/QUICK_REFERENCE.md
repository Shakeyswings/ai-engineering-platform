# AI Engineering Platform - Quick Reference Card

**Print this or bookmark it. Use it to check specs while coding.**

---

## 🎨 Color Palette (Copy-Paste CSS Variables)

```css
/* Backgrounds & Surfaces */
--bg-primary:        #0F1419;  /* Deep navy - main background */
--bg-secondary:      #1A1F2E;  /* Card backgrounds */
--bg-tertiary:       #242D3D;  /* Elevated surfaces, hover */
--bg-hover:          #2D3748;  /* Subtle hover lift */

/* Accent Colors */
--accent-cyan:       #00D4FF;  /* Primary CTA, highlights */
--accent-teal:       #00D9A3;  /* Success, secondary CTA */
--accent-purple:     #7C5AFA;  /* Gamification, badges */

/* Semantic */
--success:           #2ED573;  /* Approved, complete */
--warning:           #FFA502;  /* Needs review, caution */
--danger:            #FF4757;  /* Error, failed */
--info:              #00D4FF;  /* Information */

/* Text */
--text-primary:      #FFFFFF;     /* Headings, body */
--text-secondary:    #A8B0C0;     /* Labels, muted */
--text-tertiary:     #6B7280;     /* Metadata */
--text-inverted:     #0F1419;     /* Text on light bg */

/* Borders */
--border:            #2D3748;  /* Card borders, dividers */
--border-accent:     #00D4FF;  /* Focused, active */
--border-danger:     #FF4757;  /* Error states */
```

---

## 🔤 Typography Scale (Copy-Paste)

| Role | Size | Weight | Line-Height | Use Case |
|------|------|--------|-------------|----------|
| **H1** | 48px | 700 | 1.1 | Hero/page title |
| **H2** | 32px | 700 | 1.2 | Page section |
| **H3** | 24px | 600 | 1.3 | Card title, subsection |
| **H4** | 18px | 600 | 1.4 | Small section |
| **Body** | 14px | 400 | 1.6 | Main text |
| **Label** | 12px | 500 | 1.5 | Form labels, badges |
| **Small** | 11px | 400 | 1.4 | Metadata, hints |
| **Code** | 12px | 400 | 1.5 | Code blocks |

**Font Family:** `Inter, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif`

---

## 📐 Spacing Grid (Always Use Multiples of 4px)

```
Micro:   4px  (internal space)
Tight:   8px  (related elements)
Small:   12px (element groups)
Base:    16px (default padding/margin)
Medium:  24px (card padding)
Large:   32px (section gap)
XL:      48px (page margin)
XXL:     64px (major sections)
```

---

## 🎯 Component Specs (Quick Reference)

### Button (Primary CTA)
```
Background:  --accent-cyan (#00D4FF)
Text:        #0F1419 (inverted)
Padding:     12px H × 16px V
Height:      40px
Border-rad:  8px
Font:        14px / 600
Hover:       brightness-110
Transition:  all 150ms ease-out
Focus:       outline 2px --accent-cyan offset 2px
```

### Card
```
Background:  --bg-secondary
Border:      1px solid --border
Border-rad:  8px
Padding:     16px - 24px
Shadow:      0 4px 12px rgba(0,0,0,0.3)
Hover:       border → --accent-cyan
Transition:  all 150ms ease-out
```

### Input Field
```
Background:  --bg-tertiary
Border:      1px solid --border
Border-rad:  6px
Padding:     12px
Font:        14px / 400
Focus:       2px solid --accent-cyan
Error:       2px solid --danger
Transition:  border-color 150ms ease-out
```

### Badge / Status
```
Format:      🟢 text
Size:        12px font, 6px dot
Padding:     4px H × 6px V
Border-rad:  4px (pill)
Colors:      Success (teal), Warning (orange), Error (red), Info (cyan)
```

### Modal
```
Overlay:     rgba(15,20,25,0.8)
Container:   bg-secondary, 1px border
Border-rad:  12px
Padding:     24px
Max-width:   500px (default), 600px (form)
Shadow:      0 20px 25px rgba(0,0,0,0.5)
```

### Progress Bar
```
Height:      8px
Bg:          --border
Fill:        --accent-cyan
Border-rad:  4px
Animation:   smooth transition 200ms
```

---

## 🎮 Gamification Elements

### Achievement Badge
```
Size:        64px × 64px
Shape:       Circle or rounded square
Background:  --accent-purple (#7C5AFA)
Icon:        32px centered, white
Border:      2px solid --accent-teal
Shadow:      0 8px 24px rgba(124,90,250,0.3)
Animation:   pulse 1 → 1.1 → 1 (600ms on unlock)
```

### Streak Counter
```
Format:      🔥 {count} day streak
Background:  --accent-purple with gradient
Padding:     8px H × 12px V
Border-rad:  20px (pill)
Font:        14px / 600
Position:    Sticky top-right
Animation:   pulse on update (subtle)
```

### Reward Toast
```
Background:  --accent-teal (#00D9A3)
Text:        --text-inverted (#0F1419)
Icon:        Trophy or star (24px)
Padding:     12px H × 16px V
Duration:    Show 4s, fade-out 300ms
Animation:   Slide-in from bottom-right
Position:    Bottom-right corner
```

---

## ⚡ Animation Speeds (No Exceptions!)

```
Micro:       100ms  (hover, focus)
Fast:        150ms  (clicks, color change)
Normal:      300ms  (modal, card expand)
Slow:        600ms  (rewards, celebration)
MAX:         1000ms (anything slower feels broken)

Default:     ease-out
Snappy:      cubic-bezier(0.4, 0, 0.2, 1)
Bounce:      cubic-bezier(0.68, -0.55, 0.265, 1.55)
```

---

## 📱 Responsive Breakpoints

```
Mobile:      <768px   (secondary support)
Tablet:      768px+   (primary tablet experience)
Desktop:     1440px+  (primary target)

Sidebar:
├─ Desktop: 240px fixed visible
├─ Tablet: Collapse to icon-only (expand on hover)
└─ Mobile: Hamburger menu

Touch targets: Minimum 44px × 44px
```

---

## ✅ Accessibility Rules (MUST COMPLY)

- ✅ Color contrast ≥ 4.5:1 for all text
- ✅ Focus rings visible on all interactive elements
- ✅ Semantic HTML (proper heading hierarchy)
- ✅ ARIA labels where needed
- ✅ Keyboard navigation fully supported
- ✅ Form labels linked via `htmlFor`
- ✅ Alt text for all images
- ✅ Lighthouse A11y score ≥ 90

---

## 🚫 Design Anti-Patterns (NEVER DO)

- ❌ New colors (use palette only)
- ❌ Font sizes outside type scale
- ❌ Padding/margins not divisible by 4px
- ❌ Focus rings hidden or removed
- ❌ Animations >600ms
- ❌ Text contrast <4.5:1
- ❌ Gradients (they cloud the brand)
- ❌ Rounded corners >12px
- ❌ Shadows with no blur (harsh)
- ❌ Cute emojis (professional only)
- ❌ 100% full-width buttons on desktop
- ❌ Color as only visual indicator

---

## 🔗 CSS Variable Template (Paste into `globals.css`)

```css
:root {
  /* Backgrounds */
  --bg-primary: #0F1419;
  --bg-secondary: #1A1F2E;
  --bg-tertiary: #242D3D;
  --bg-hover: #2D3748;

  /* Accents */
  --accent-cyan: #00D4FF;
  --accent-teal: #00D9A3;
  --accent-purple: #7C5AFA;

  /* Semantic */
  --color-success: #2ED573;
  --color-warning: #FFA502;
  --color-danger: #FF4757;
  --color-info: #00D4FF;

  /* Text */
  --text-primary: #FFFFFF;
  --text-secondary: #A8B0C0;
  --text-tertiary: #6B7280;
  --text-inverted: #0F1419;

  /* Borders */
  --border: #2D3748;
  --border-accent: #00D4FF;
  --border-danger: #FF4757;

  /* Spacing */
  --space-xs: 4px;
  --space-sm: 8px;
  --space-md: 12px;
  --space-base: 16px;
  --space-lg: 24px;
  --space-xl: 32px;
  --space-2xl: 48px;

  /* Transitions */
  --transition-fast: 150ms ease-out;
  --transition-normal: 300ms ease-out;
  --transition-slow: 600ms ease-out;
}
```

---

## 🎯 Common Component Examples

### Button Component (React)
```tsx
<button className="
  bg-[var(--accent-cyan)] 
  text-[var(--text-inverted)]
  px-4 py-3 rounded-lg
  font-medium text-sm
  hover:brightness-110
  transition-all duration-150
  focus:outline-2 focus:outline-offset-2 focus:outline-[var(--accent-cyan)]
">
  Click Me
</button>
```

### Card Component (React)
```tsx
<div className="
  bg-[var(--bg-secondary)]
  border border-[var(--border)]
  rounded-lg p-6
  hover:border-[var(--accent-cyan)]
  transition-colors duration-150
  shadow-md
">
  Card content
</div>
```

### Form Input (React)
```tsx
<input
  className="
    w-full
    bg-[var(--bg-tertiary)]
    border border-[var(--border)]
    rounded-md px-3 py-3
    text-[var(--text-primary)]
    focus:border-[var(--accent-cyan)]
    focus:outline-none focus:ring-2 focus:ring-[var(--accent-cyan)]
    placeholder-[var(--text-tertiary)]
  "
  placeholder="Enter text..."
/>
```

---

## 📊 Contrast Checking Quick Guide

**Use this to verify contrast ratios:**

| Foreground | Background | Ratio | Pass? |
|-----------|-----------|-------|-------|
| #FFFFFF (text-primary) | #1A1F2E (bg-secondary) | ~15:1 | ✅ Excellent |
| #A8B0C0 (text-secondary) | #1A1F2E (bg-secondary) | ~5.5:1 | ✅ Good |
| #6B7280 (text-tertiary) | #1A1F2E (bg-secondary) | ~3:1 | ⚠️ Borderline (avoid) |

**Tool:** Use WebAIM Contrast Checker → https://webaim.org/resources/contrastchecker/

---

## 🎬 Animation Keyframes Template

```css
@keyframes pulse {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.5; }
}

@keyframes slideIn {
  from { transform: translateX(100%); opacity: 0; }
  to { transform: translateX(0); opacity: 1; }
}

@keyframes scaleIn {
  from { transform: scale(0.95); opacity: 0; }
  to { transform: scale(1); opacity: 1; }
}

.animate-pulse { animation: pulse 2s infinite; }
.animate-slideIn { animation: slideIn 300ms ease-out; }
.animate-scaleIn { animation: scaleIn 300ms ease-out; }
```

---

## 📋 QA Checklist (Before Committing)

- [ ] All colors from palette
- [ ] Type scale used correctly
- [ ] Spacing is multiple of 4px
- [ ] Focus rings visible on all interactive elements
- [ ] Hover states defined
- [ ] Disabled state handled
- [ ] Text contrast ≥4.5:1
- [ ] Responsive (desktop, tablet)
- [ ] Animations <600ms
- [ ] No console errors
- [ ] Component works in isolation
- [ ] Passes Lighthouse A11y ≥90

---

## 🔑 Key Files Reference

| File | Purpose | Update When |
|------|---------|------------|
| **CONTEXT.md** | Architecture & principles | Major changes to project direction |
| **UI_CONSTRAINTS.md** | Visual rules & specs | Design decisions change |
| **QUICK_REFERENCE.md** | This file, quick lookup | Add new components |
| **GPT_PROMPTS_PHASE_1-3.md** | Exact prompts to send GPT | New phases added |

---

**Print this page. Keep it on your desk. Reference constantly. 📌**

Last Updated: 2026-07-03
